from django.shortcuts import render,redirect
import requests
from .models import city
from .forms import cityForm
#query=New%20York

# Create your views here.
def index(request):
    weather_data=[]
    if(request.method== 'POST'):
        form= cityForm(request.POST)
        if(form.is_valid):
            form.save()
        
        return  redirect("/")

       
    form= cityForm()
    url= 'http://api.weatherstack.com/current?access_key=3052edc8e8a4356dfeaf545577e082e3&'
    cities= city.objects.all()
    i=0

    for City in cities:
        i+=1
        if(i<5):
            resp=requests.get(url+"query="+City.name).json()
    
    
            city_weather={
            'city': resp['location']['name'],
            'temperature': resp['current']['temperature'],
            'description':resp['current']['weather_descriptions'][0],
            'image':resp['current']['weather_icons'][0]

            }
            weather_data.append(city_weather)
        
    
   
    
    context={'weather_data':weather_data,'form':form}
    return render(request,'weatherapp/weather.html',context)
