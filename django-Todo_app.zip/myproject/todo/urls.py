from django.urls import path
from . import views
urlpatterns = [
    path('', views.index,name="list"),
     path('update/<str:primarykey>', views.updateTodo,name="updatetodo"),
     path('delete/<str:primarykey>', views.deleteTodo,name="deletetodo"),
]