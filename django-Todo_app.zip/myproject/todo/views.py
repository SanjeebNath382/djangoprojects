from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import *
from .forms import *

# Create your views here.
def index(request):
    tasks= todo.objects.all()
    form= todoForm()
    if request.method == "POST":
        form= todoForm(request.POST) 
        if form.is_valid():
            form.save()
        return  redirect("/")
    context={'tasks':tasks,'form':form}
    return render(request,'todo/index.html',context)
def  updateTodo(request, primarykey):
    todoselected= todo.objects.get(id=primarykey)
    form= todoForm(instance=todoselected)
    if request.method == "POST":
        form= todoForm(request.POST,instance=todoselected)
        if form.is_valid():
            form.save()
        return redirect("/")
            
    context={"form":form}

    return render(request,"todo/updateTodo.htm",context)
def  deleteTodo(request, primarykey):
    todoselected= todo.objects.get(id=primarykey)
    if(request.method=="POST"):
            todoselected.delete()
            return redirect("/")
    context={"todoselected":todoselected}
    
    

    return render(request,"todo/delete.html",context)
